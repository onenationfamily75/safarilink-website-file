# SafariLink Air — Google Search Console Setup Guide
## Files in This Package

| File | Purpose |
|---|---|
| `index.html` | Homepage — patched with all SEO meta tags |
| `sitemap.xml` | Submit this to Google Search Console |
| `robots.txt` | Guides Googlebot crawling |
| `manifest.json` | Progressive Web App manifest |
| `.htaccess` | Server config — MIME types, HTTPS redirect |
| `google-site-verification.html` | Replace with your actual GSC verification file |

---

## Step-by-Step: Add to Google Search Console

### Step 1 — Verify Ownership
1. Go to → https://search.google.com/search-console/
2. Click **"Add property"**
3. Enter: `https://flysafarilinkairline.com`
4. Choose verification method:
   - **HTML file** → download file → upload to root → click Verify
   - **Meta tag** → copy the token → paste into `index.html` replacing `REPLACE_WITH_YOUR_GSC_TOKEN`

### Step 2 — Submit Sitemap
1. In GSC left menu → click **"Sitemaps"**
2. Paste: `https://flysafarilinkairline.com/sitemap.xml`
3. Click **"Submit"**
4. Google will show status: ✅ Success (usually within 24 hours)

### Step 3 — Request Indexing
1. In GSC → click **"URL Inspection"** in left menu
2. Paste your URL: `https://flysafarilinkairline.com/`
3. Click **"Request Indexing"**
4. Repeat for each important page:
   - `https://flysafarilinkairline.com/destinations`
   - `https://flysafarilinkairline.com/book`
   - `https://flysafarilinkairline.com/packages`
   - `https://flysafarilinkairline.com/contact`

### Step 4 — Upload All Files
Upload these to your web hosting root (`public_html/`):
```
public_html/
├── index.html         ✅ (patched)
├── sitemap.xml        ✅ (new)
├── robots.txt         ✅ (new)
├── manifest.json      ✅ (new)
├── .htaccess          ✅ (new)
└── google-site-verification.html  ← replace with your actual GSC file
```

---

## Fixes Applied to index.html
- ✅ Added `google-site-verification` meta tag (replace token)
- ✅ Added favicon SVG
- ✅ Added `<link rel="manifest">` for PWA
- ✅ Added `<link rel="sitemap">` in `<head>`
- ✅ Added `hreflang` tags for English
- ✅ Added `preconnect` for Google Fonts
- ✅ Added `WebSite` schema with SearchAction
- ✅ Added `BreadcrumbList` schema for all pages
- ✅ Fixed nav links to proper absolute URLs
- ✅ Fixed footer email address

## Sitemap Contents
- 7 core pages (Home, Destinations, Book, Packages, About, Contact, FAQ)
- 16 destination pages (Masai Mara, Zanzibar, Lamu, Diani Beach, Amboseli, Samburu, Malindi, Naivasha, Nanyuki, Tsavo West, Loisaba, Mombasa, Kisumu, Entebbe, Arusha, Lewa Downs)
- Total: **23 URLs** with correct priorities and changefreq
